<div class="shop_sidebar col-md-3">
    <?php dynamic_sidebar("shop"); ?>
<div class="shop_sidebar">