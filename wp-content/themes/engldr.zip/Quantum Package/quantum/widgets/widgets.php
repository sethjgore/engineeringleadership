<?php
    require_once "widget-latest-posts.php";
    require_once "widget-contact-form.php";
?>